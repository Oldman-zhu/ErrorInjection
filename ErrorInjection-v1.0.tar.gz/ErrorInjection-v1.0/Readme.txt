Author:zhushg
Date:2020.09.06
Aim:To inject PCIe error, Memeory or Processor error use ACPI EINJ Table under OS When we are not equiped XDP or DCI Devices
Verion:1.0

1.Introduction:
    This tool is used for inject memory and PCIe error in Intel Platform,processor error in Hygon and AMD Platfrom by ACPI EINJ Table.SO,BIOS should support ACPI first. And Whea terms also should be set in BIOS in Intel Platfrom.The error type can be classified as correctable error(ce),uncorrectable-non fatal error(uce-nonfatal) and uncorrectable fatal error(uce-fatal).
2.BIOS Settings&Supported Error
  1.Memory:WHEA Error injection Support-->Enable;WHEA Error Injection 5.0 Extension-->Enabled
  2.PCIe:WHEA Error injection Support-->Enable;WHea PCIE Error injection Support-->Enable;Whea PCIE Error Injection Action Table-->Enabled
3.Usage:
  usage: ErrInject.sh [-d Device] [-e Error_type][-a Adress]
    
           -h help         Dispaly help information
           -d Device       Specify a device will be injected error
           -e Error_type   Specify the error Type
           -a Adrress      Phycial adress used for injecting error,"random" represent random address
    
    Device:
          Mem             Memory 
          PCIe            PCI Express
          Proc            Processor
   
    Error_type:
         ce              Correctable Error
         uce-nonfatal    Uncorrectable Error nonfatal
         uce-fatal       Uncorrectable Error fatal
    

