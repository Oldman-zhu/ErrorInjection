#!/bin/bash

#****************************************************************************************************************
#Author:zhushg
#Date:2020.8.26
#Aim:To inject PCIe error or Memeory error use ACPI EINJ Table under OS When we are not equiped XPD or DCI Devices
#
#****************************************************************************************************************

Devs=$1
ErrType=$2
ErrLocation=$3
Cur_Dir=$(cd "$(dirname "$0")";pwd)
einj_dir="/sys/kernel/debug/apei/einj"

#sh /$Cur_Dir/tool/ pre.sh >>einj.txt  #Load acpi einj table

sh $Cur_Dir/tool/ pre.sh > $Cur_Dir/einj.txt 2>&1  #Load acpi einj table
Invalid=`cat einj.txt|grep -i 'modprobe:ERROR'`
if [ $Invalid ! = ' '];then
   echo "Please Set WHEA in BIOS Setup"
else
   echo "#***************************************************#"
   echo "#               WHEA was set successed               #"
   echo "#***************************************************#"
fi

function error_type(){
   cd $einj_dir
   cat available_error_type |awk '{print $2" "$3" "$4" "$5" "$6}'
}
function help(){
    echo "Usage:"
    echo "The supported error type is as follow"
    error_type()
    linenum=`cat available_error_type |wc -l`
    if [ $linenum -eq 3 ];then
       echo "1.use sh ErrorInjection.sh Mem ce xxxx(specific memory address) or random to inject a memory correctable error"
       echo "2.use sh ErrorInjection.sh Mem uce-nonfatal xxxx(specific memory address) or random to inject a memory uncorrectable nonfatal error"
       echo "3.use sh ErrorInjection.sh Mem uce-fatal xxxx(specific memory address) or random to inject a memory uncorrectable fatal error"   
    else if [ $linenum -eq 6];then
            echo "1.use sh ErrorInjection.sh Mem ce xxxx(specific memory address) or random to inject a memory correctable error"
            echo "2.use sh ErrorInjection.sh Mem uce-nonfatal xxxx(specific memory address) or random to inject a memory uncorrectable nonfatal error"
            echo "3.use sh ErrorInjection.sh Mem uce-fatal xxxx(specific memory address) or random to inject a memory uncorrectable fatal error" 
            echo "4.use sh ErrorInjection.sh PCIe ce to inject a PCIe correctable error"
            echo "2.use sh ErrorInjection.sh PCIe uce-nonfatal to inject a memory uncorrectable nonfatal error"
            echo "3.use sh ErrorInjection.sh PCIe uce-fatal to inject a memory uncorrectable fatal error"  
    fi
fi
}
#params lack Tips
if [ -z "$Devs"  ];then
    echo "Please input devices type:Mem or Pcie"
    exit -1
fi
if [ -z "$ErrType"  ];then
    echo "Please input error type:ce,uce-nonfatal or uce-fatal"
    exit -1
fi
if [ -z "$ErrLocation"  ];then
    echo "The error Location will be random "
    for i in $(seq 10 -1 1)
    do
        echo "if you want to stop,please press "Ctrc+C"" 
        echo -e "$i/s";sleep 1
    done 
    echo -e "Begin the test"  
fi
#Judge for adress of memory
function Address(){
    if [ -z $ErrorLocation -a $Devs -eq 'Mem' ];then   
        ./$Cur_dir/mca-recover >address.tx 2>&1
    fi
}
