 set -v
 cd /sys/kernel/debug/apei/einj
 cat error_type > /dev/null 2>&1
 echo $1 >error_type
 #echo $2 > param1
 echo 0xfffffffffffff000 >param2
 echo 0 > notrigger
 echo 1 > error_inject
 

